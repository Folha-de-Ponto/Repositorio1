function history()
{
    location.href="history.html"
}
function telaponto()
{
    location.href="index.html"
}
function users()
{
    location.href="usuarios.html"
}
function deslogar()
{
    localStorage.logado = false
    location.href = "login.html"

}